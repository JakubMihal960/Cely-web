// ===================================
// ÚLOHA 1: Základné údaje 
// ===================================
// Vytvor 4 premenné podľa toho, kde v akom elemente sa majú vypísať
// Daj si do premenných aj elementy, s ktorými budeš pracovaťm vytiahni si ich podľa ID
// 



// ===================================
// ÚLOHA 2: Zobrazenie údajov 
// ===================================
// Použi textContent na zobrazenie všetkých 4 údajov v jednotlivých elementoch
//




// ===================================
// ÚLOHA 3: Zmena farieb (6 bodov)
// ===================================
// 1. Najdi id tlačidla tak aby si s ním mohol pracovať, a tiež element, ktorých ich všetky obaľuje, aby si mu mohol zmeniť farbu orámovania
// 2. Pridaj mu event listener nech reaguje na udalosť 'click'
// 3. Pri kliknutí prepni triedu 'zmenene-farby' na elemente s triedou .container 
//    Použiješ: classList.toggle("zmenene-farby");



// ===================================
// ÚLOHA 4: Výpočet roku narodenia
// ===================================
// Vypočítaj rok narodenia,u lož do premennej, zobraz do elementu 




// ===================================
// BONUS: Zmena textu tlačidla (4 body)
// ===================================
// Voliteľné 
// Zmeň text tlačidla z "Zmeniť farby" na "Pôvodné farby" a naspäť


